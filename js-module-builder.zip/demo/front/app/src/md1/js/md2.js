define(function(require, module, exports){
    console.log('md2 aa bb cc');
})