define(function(require, module, exports){
    console.log('md1');
    console.log('__("this is a test")');
})