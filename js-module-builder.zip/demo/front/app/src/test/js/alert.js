define(function(require, module, exports){
    alert('aaa');
    require('../../md1/js/md1.index.js');
    require('../../md1/js/md2.js');
})