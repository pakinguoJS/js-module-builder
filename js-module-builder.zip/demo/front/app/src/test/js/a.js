define(function(require, module, exports){
    console.log('a');
    var t;
})