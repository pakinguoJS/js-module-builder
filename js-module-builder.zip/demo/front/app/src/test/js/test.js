define(function(require, module, exports){
	console.log('just for a test')
})