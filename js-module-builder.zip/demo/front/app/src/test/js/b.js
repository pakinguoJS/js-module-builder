define(function(require, module, exports){
    console.log('b');
})